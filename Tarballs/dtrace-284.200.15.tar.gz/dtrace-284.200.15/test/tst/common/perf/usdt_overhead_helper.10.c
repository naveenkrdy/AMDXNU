#include <usdt_overhead_helper.h>
int main(void) {
    PROV10()
    return 0;
}

