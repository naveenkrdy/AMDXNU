
void f(void) {

}

void g(void) {

}

int main(void) {
	f();
	f();
	g();

	return 0;
}
